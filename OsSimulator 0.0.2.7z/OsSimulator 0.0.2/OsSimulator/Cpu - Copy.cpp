#include "Cpu.h"

int MESSAGE_OUT_OF_RANGE[] = {
    1, 73, // I
    9, 2,
    1, 110, // n
    9, 2,
    1, 118, // v
    9, 2,
    1, 97, // a
    9, 2,
    1, 108, // l
    9, 2,
    1, 105, // i
    9, 2,
    1, 100, // d
    9, 2,
    1, 32, // _
    9, 2,
    1, 105, // i
    9, 2,
    1, 110, // n
    9, 2,
    1, 100, // d
    9, 2,
    1, 101, // e
    9, 2,
    1, 120, // x
    9, 2,
    1, 33, // !
    9, 2,
    1, 10, // \n
    9, 2,
    50 // END program
};

int MESSAGE_ILLEGAL_ACCESS[] = {
    1, 65, // A
    9, 2,
    1, 99, // c
    9, 2,
    1, 99, // c
    9, 2,
    1, 101, // e
    9, 2,
    1, 115, // s
    9, 2,
    1, 115, // s
    9, 2,
    1, 32, // _
    9, 2,
    1, 101, // e
    9, 2,
    1, 114, // r
    9, 2,
    1, 114, // r
    9, 2,
    1, 111, // o
    9, 2,
    1, 114, // r
    9, 2,
    1, 33, // !
    9, 2,
    1, 10, // \n
    9, 2,
    50 // End program!
};


Cpu::Cpu()
{
    this->interrupt = false;
    this->userSP = START_USER_STACK_INDEX;
    this->systemSP = START_SYSTEM_STACK_INDEX;
    this->registerPC = 0;
    this->registerIR = 0;
    this->registerAC = 0;
    this->registerSP = userSP;
    this->registerX = 0;
    this->registerY = 0;
    this->terminate = false;
}

Cpu::~Cpu()
{
}

void Cpu::run()
{
    int count = 0;
    while (!this->isTerminate())
    {
        fetchIR();

        if (!this->isInterrupt())
        {
            count++;
        }
        this->executeInstruction();
        if (count == this->timer)
        {
            this->interruptTimer();
            count = 0;
        }
    }
    
}

void Cpu::fetchIR()
{
    this->registerIR = this->memory.read(this->registerPC++);
}

void Cpu::executeInstruction()
{
    try
    {
        switch (this->registerIR)
        {
            case LOAD_VALUE:
            {
                //this->loadValue();
                break;
            }
            case LOAD_ADDR:
            {
                //this->loadAddr();
                break;
            }
            case LOAD_IND:
            {
                //this->loadInd();
                break;
            }
            case LOAD_IND_X:
            {
                //this->loadIndX();
                break;
            }
            case LOAD_IND_Y:
            {
                //this->loadIndY();
                break;
            }
            case LOAD_SP_X:
            {
                //this->loadSpX();
                break;
            }
            case STORE_ADDR:
            {
                //this->storeAddr();
                break;
            }
            case GET:
            {
                this->get();
                break;
            }
            case PUT_PORT:
            {
                this->putPort();
                break;
            }
            case ADD_X:
            {
                this->addX();
                break;
            }
            case ADD_Y:
            {
                this->addY();
                break;
            }
            case SUB_X:
            {
                this->subX();
                break;
            }
            case SUB_Y:
            {
                break;
            }
            case COPY_TO_X:
            {
                this->copyToX();
                break;
            }
            case COPY_FROM_X:
            {
                break;
            }
            case COPY_TO_Y:
            {
                this->copyToY();
                break;
            }
            case COPY_FROM_Y:
            {
                break;
            }
            case COPY_TO_SP:
            {
                break;
            }
            case COPY_FROM_SP:
            {
                break;
            }
            case JUMP_ADDR:
            {
                //this->jumpAddr();
                break;
            }
            case JUMP_IF_EQUAL_ADDR:
            {
                //this->jumpIfEqualAddr();
                break;
            }
            case JUMP_IF_NOT_EQUAL_ADDR:
            {
                //this->jumpIfNotEqualAddr();
                break;
            }
            case CALL_ADDR:
            {
                //this->callAddr();
                break;
            }
            case RET:
            {
                //this->ret();
                break;
            }
            case INC_X:
            {
                //this->incX();
                break;
            }
            case DEC_X:
            {
                //this->decX();
                break;
            }
            case PUSH_AC:
            {
                //this->pushAC();
                break;
            }
            case POP_AC:
            {
                //this->popAC();
                break;
            }
            case INT:
            {
                //this->inc();
                break;
            }
            case IRET:
            {
                this->iret();
                break;
            }
            case END:
            {
                this->end();
                break;
            }
            case default:
                break;
        }
    }
    catch (OutOfRangeException)
    {
        printMessage(MESSAGE_OUT_OF_RANGE);
    }
    catch (IllegalAccessException)
    {
        printMessage(MESSAGE_ILLEGAL_ACCESS);
    }
}

void Cpu::loadValue(int value)
{
    this->registerAC = value;
}

void Cpu::loadAddr(int addr)
{
    this->registerAC = memory[addr];
}

void Cpu::loadInd(int addr)
{
    if (addr % 100 == 0) {
        this->registerAC = memory[100];
    }
}

void Cpu::loadIndX(int addr)
{
    if (addr % 10 == 0) {
        this->registerAC = memory[addr + 10];
    }
}

void Cpu::loadIndY(int addr)
{
    // ?
}

void Cpu::loadIndSP()
{
    // ?
}

void Cpu::storeAddr(int addr)
{
    memory[addr] = this->registerAC;
}

void Cpu::get()
{
    int value = 1 + rand() % 100;
    this->registerAC = value;
}

void Cpu::putPort()
{
    int port = this->memory.read(registerPC++);
    if (port == 1) {
        printNumber(this->registerAC);
    }
    else if (port == 2) {
        this->printCharacter(this->registerAC);
    }
}

void Cpu::printNumber(int data) {
    cout << data;
}

void Cpu::printCharacter(int data) {
    cout << char(data);
}

void Cpu::addX()
{
    this->registerAC += this->registerX;
}

void Cpu::addY()
{
    this->registerAC += this->registerY;
}

void Cpu::subX()
{
    this->registerAC -= this->registerX;
}

void Cpu::subY()
{
    this->registerAC -= this->registerY;
}

void Cpu::copyToX()
{
    this->registerX = this->registerAC;
}

void Cpu::copyFromX()
{
    this->registerAC = this->registerX;
}

void Cpu::copyToY()
{
    this->registerY = this->registerAC;
}

void Cpu::copyFromY()
{
    this->registerAC = this->registerY;
}

void Cpu::copyToSP()
{
    this->registerSP = this->registerAC;
}

void Cpu::copyFromSP()
{
    this->registerAC = this->registerSP;
}

void Cpu::jumpAddr(int addr)
{
    this->systemSP = addr;
}

void Cpu::jumpIfEqualAddr(int addr)
{
    int val = this->registerAC;
    if (val == 0) {
        this->systemSP = addr;
    }
}

void Cpu::jumpIfNotEqualAddr(int addr)
{
    int val = this->registerAC;
    if (val != 0) {
        this->systemSP = addr;
    }
}

void Cpu::callAddr(int addr)
{
    // ?
}

void Cpu::ret()
{
    // ?
}

void Cpu::incX()
{
    this->registerX += 1;
}

void Cpu::decX()
{
    this->registerX -= 1;
}

void Cpu::pushAC()
{
    // ?
}

void Cpu::popAC()
{
    // ?
}

void Cpu::inc()
{
    // ?
}

void Cpu::end()
{
    this->setTerminate(true);
}

void Cpu::switchToUserStack() 
{
    this->userSP = this->registerSP;
}

void Cpu::switchToSystemStack()
{
    this->systemSP = this->registerSP;
}

void Cpu::interruptTimer()
{
    if (!this->isInterrupt())
    {
        this->setInterrupt(true);
        this->memory.setMode(SYSTEM_MODE);
        this->switchToSystemStack();
        this->systemSP = this->storeRegister(this->systemSP);
        this->setNewPcSPRegister(TIMER_INTERRUPT_ADDR, this->systemSP);
        
        //check timer program
        if (memory.read(TIMER_INTERRUPT_ADDR) == 0) {
            iret();
        }
    }
}

void Cpu::setInterrupt(bool interrupt) {
    this->interrupt = interrupt;
}

bool Cpu::isInterrupt() {
    return this->interrupt;
}

void Cpu::setTerminate(bool terminate) {
    this->terminate = terminate;
}

bool Cpu::isTerminate() {
    return terminate;
}

int Cpu::storeRegister(int stackPoint) 
{
    this->memory.write(stackPoint--, this->registerY);
    this->memory.write(stackPoint--, this->registerX);
    this->memory.write(stackPoint--, this->registerAC);
    this->memory.write(stackPoint--, this->registerSP);
    this->memory.write(stackPoint--, this->registerPC);

    return stackPoint;
}

void Cpu::setNewPcSPRegister(int pc, int sp) 
{
    this->registerPC = pc;
    this->registerSP = sp;
}

void Cpu::iret() 
{
    this->setInterrupt(false);
    this->switchToUserStack();
    this->systemSP = this->restoreRegisterFromStack(this->systemSP);
    this->memory.setMode(USER_MODE);
}

int Cpu::restoreRegisterFromStack(int stackPoint) 
{
    this->registerPC = memory.read(++stackPoint);
    this->registerSP = memory.read(++stackPoint);
    this->registerAC = memory.read(++stackPoint);
    this->registerX = memory.read(++stackPoint);
    this->registerY = memory.read(++stackPoint);
    return stackPoint;
}

void Cpu::setTimer(int value) 
{
    this->timer = value;
}

void Cpu::printMessage(int instructions[])
{
    this->writeInterruptProgram(SYSTEM_INTERRUPT_ADDR, instructions);
    this->interruptSystem();
    run();
}

void Cpu::initialize(int memory[])
{
    this->memory.initialize(memory);
}

void Cpu::writeInterruptProgram(int interruptAddr, int instructions[]) 
{
    //switch to system mode to write intTimer program if current mode is user mode
    bool isSwitch = false;
    if (this->memory.getMode() == USER_MODE) {
        this->memory.setMode(SYSTEM_MODE);
        isSwitch = true;
    }

    int intstructionLength = (sizeof(instructions)) / (sizeof(*instructions));
    //write message to system intTimer memory 
    for (int i = 0; i < intstructionLength; i++)
    {
        memory.write(interruptAddr + i, instructions[i]);
    }

    //switch to user mode before call this function
    if (isSwitch) 
    {
        this->memory.setMode(USER_MODE);
    }
}

void Cpu::interruptSystem()
{

}