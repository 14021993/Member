#include "Cpu.h"

Cpu::Cpu()
{
    this->interrupt = false;
    this->userSP = START_USER_STACK_INDEX;
    this->systemSP = START_SYSTEM_STACK_INDEX;
    this->registerPC = 0;
    this->registerIR = 0;
    this->registerAC = 0;
    this->registerSP = userSP;
    this->registerX = 0;
    this->registerY = 0;
    this->terminate = false;
	this->count = 0;
}

Cpu::~Cpu()
{
}

void Cpu::run()
{
    while (!this->isTerminate())
    {
        fetchIR();

        if (!this->isInterrupt())
        {
            this->count = this->count++;
        }
        this->executeInstruction();
        if (this->count == this->timer)
        {
            this->interruptTimer();
            this->count = 0;
        }
    }
    
}

void Cpu::fetchIR()
{
    this->registerIR = this->memory.read(this->registerPC++);
}

void Cpu::executeInstruction()
{
    try
    {
        switch (this->registerIR)
        {
            case LOAD_VALUE:
            {
				this->loadValue();
                break;
            }
            case LOAD_ADDR:
            {
				this->loadAddr();
                break;
            }
            case LOAD_IND:
            {
				this->loadInd();
                break;
            }
            case LOAD_IND_X:
            {
				this->loadIndX();
                break;
            }
            case LOAD_IND_Y:
            {
                this->loadIndY();
                break;
            }
            case LOAD_SP_X:
            {
                this->loadSpX();
                break;
            }
            case STORE_ADDR:
            {
                this->storeAddr();
                break;
            }
            case GET:
            {
                this->get();
                break;
            }
            case PUT_PORT:
            {
                this->putPort();
                break;
            }
            case ADD_X:
            {
                this->addX();
                break;
            }
            case ADD_Y:
            {
                this->addY();
                break;
            }
            case SUB_X:
            {
                this->subX();
                break;
            }
            case SUB_Y:
            {
				this->subY();
                break;
            }
            case COPY_TO_X:
            {
                this->copyToX();
                break;
            }
            case COPY_FROM_X:
            {
				this->copyFromX();
                break;
            }
            case COPY_TO_Y:
            {
                this->copyToY();
                break;
            }
            case COPY_FROM_Y:
            {
				this->copyFromY();
                break;
            }
            case COPY_TO_SP:
            {
				this->copyToSP();
                break;
            }
            case COPY_FROM_SP:
            {
				this->copyFromSP();
                break;
            }
            case JUMP_ADDR:
            {
				this->jumpAddr();
                break;
            }
            case JUMP_IF_EQUAL_ADDR:
            {
                this->jumpIfEqualAddr();
                break;
            }
            case JUMP_IF_NOT_EQUAL_ADDR:
            {
                this->jumpIfNotEqualAddr();
                break;
            }
            case CALL_ADDR:
            {
                this->callAddr();
                break;
            }
            case RET:
            {
                this->ret();
                break;
            }
            case INC_X:
            {
                this->incX();
                break;
            }
            case DEC_X:
            {
                this->decX();
                break;
            }
            case PUSH_AC:
            {
                this->pushAC();
                break;
            }
            case POP_AC:
            {
                this->popAC();
                break;
            }
            case INT:
            {
                this->inc();
                break;
            }
            case IRET:
            {
                this->iret();
                break;
            }
            case END:
            {
                this->end();
                break;
            }
            default:
                break;
        }
    }
    catch (OutOfRangeException)
    {
        printMessage(MESSAGE_OUT_OF_RANGE);
    }
    catch (IllegalAccessException)
    {
        printMessage(MESSAGE_ILLEGAL_ACCESS);
    }
}

void Cpu::loadValue()
{
	this->registerAC = memory.read(this->registerPC++);
}

void Cpu::loadAddr()
{
	int addr = 0;
	addr = memory.read(this->registerPC++);
	this->registerAC = memory.read(addr);
}

void Cpu::loadInd()
{
	int addr = 0;
	addr = memory.read(this->registerPC++);
	int valueOfAddr = memory.read(addr);
	this->registerAC = memory.read(valueOfAddr); 
}

void Cpu::loadIndX()
{
	int addr = 0;
	addr = memory.read(this->registerPC++);
	this->registerAC = memory.read(addr + this->registerX);
}

void Cpu::loadIndY()
{
	int addr = 0;
	addr = memory.read(this->registerPC++);
	this->registerAC = memory.read(addr + this->registerY);
}

void Cpu::loadSpX()
{
	this->registerAC = memory.read(this->registerSP + this->registerX);
}

void Cpu::storeAddr()
{
	int addr = 0;
	addr = memory.read(this->registerPC++);
	memory.write(addr, this->registerAC);
}

void Cpu::get()
{
    int value = 1 + rand() % 100;
    this->registerAC = value;
}

void Cpu::putPort()
{
    int port = this->memory.read(registerPC++);
    if (port == 1) 
    {
        printNumber(this->registerAC);
    }
    else if (port == 2) 
    {
        this->printCharacter(this->registerAC);
    }
}

void Cpu::printNumber(int data) 
{
    cout << data;
}

void Cpu::printCharacter(int data) 
{
    cout << char(data);
}

void Cpu::addX()
{
    this->registerAC += this->registerX;
}

void Cpu::addY()
{
    this->registerAC += this->registerY;
}

void Cpu::subX()
{
    this->registerAC -= this->registerX;
}

void Cpu::subY()
{
    this->registerAC -= this->registerY;
}

void Cpu::copyToX()
{
    this->registerX = this->registerAC;
}

void Cpu::copyFromX()
{
    this->registerAC = this->registerX;
}

void Cpu::copyToY()
{
    this->registerY = this->registerAC;
}

void Cpu::copyFromY()
{
    this->registerAC = this->registerY;
}

void Cpu::copyToSP()
{
    this->registerSP = this->registerAC;
}

void Cpu::copyFromSP()
{
    this->registerAC = this->registerSP;
}

void Cpu::jumpAddr()
{
	int addr = 0;
	addr = this->registerPC;
    this->registerAC = this->memory.read(addr);
}

void Cpu::jumpIfEqualAddr()
{
    if (this->registerAC == 0)
    {
        int addr = 0;
        addr = memory.read(this->registerPC++);
        this->registerPC = addr;
    }
    else
    {
        this->registerPC++;
    }
	
}

void Cpu::jumpIfNotEqualAddr()
{
    if (this->registerAC != 0)
    {
        int addr = 0;
        addr = memory.read(this->registerPC++);
        this->registerPC = addr;
    }
    else
    {
        this->registerPC++;
    }
}

void Cpu::callAddr()
{
	int addr = 0;
	addr = memory.read(this->registerPC++);

    memory.write(this->registerSP--, this->registerPC);
    //jump to the address
    this->registerPC = addr;
}

void Cpu::ret()
{
	int returnAddr = memory.read(++this->registerSP);
	this->registerPC = returnAddr;
}

void Cpu::pushAC()
{
	this->memory.write(this->registerSP--, this->registerAC);
}

void Cpu::popAC()
{
	this->registerAC = this->memory.read(++this->registerSP);
}

void Cpu::inc()
{
	// ?
}

void Cpu::incX()
{
    this->registerX += 1;
}

void Cpu::decX()
{
    this->registerX -= 1;
}

void Cpu::end()
{
    this->setTerminate(true);
}

void Cpu::switchToUserStack() 
{
    this->systemSP = this->registerSP;
}

void Cpu::switchToSystemStack()
{
    this->userSP = this->registerSP;
}

void Cpu::interruptTimer()
{
    if (!this->isInterrupt())
    {
        this->setInterrupt(true);
        this->memory.setMode(SYSTEM_MODE);
        this->switchToSystemStack();
        this->systemSP = this->storeRegister(this->systemSP);
        this->setNewPcSPRegister(TIMER_INTERRUPT_ADDR, this->systemSP);
        
        //check timer program
        if (this->memory.read(TIMER_INTERRUPT_ADDR) == 0) {
            iret();
        }
    }
}

void Cpu::setInterrupt(bool interrupt) {
    this->interrupt = interrupt;
}

bool Cpu::isInterrupt() {
    return this->interrupt;
}

void Cpu::setTerminate(bool terminate) {
    this->terminate = terminate;
}

bool Cpu::isTerminate() {
    return terminate;
}

int Cpu::storeRegister(int stackPoint) 
{
    this->memory.write(stackPoint--, this->registerY);
    this->memory.write(stackPoint--, this->registerX);
    this->memory.write(stackPoint--, this->registerAC);
    this->memory.write(stackPoint--, this->registerSP);
    this->memory.write(stackPoint--, this->registerPC);

    return stackPoint;
}

void Cpu::setNewPcSPRegister(int pc, int sp) 
{
    this->registerPC = pc;
    this->registerSP = sp;
}

void Cpu::iret() 
{
    this->setInterrupt(false);
    this->switchToUserStack();
    this->systemSP = this->restoreRegisterFromStack(this->systemSP);
    this->memory.setMode(USER_MODE);
}

int Cpu::restoreRegisterFromStack(int stackPoint) 
{
    this->registerPC = memory.read(++stackPoint);
    this->registerSP = memory.read(++stackPoint);
    this->registerAC = memory.read(++stackPoint);
    this->registerX = memory.read(++stackPoint);
    this->registerY = memory.read(++stackPoint);
    return stackPoint;
}

void Cpu::setTimer(int value) 
{
    this->timer = value;
}

void Cpu::printMessage(ErrorType error)
{
    this->writeInterruptProgram(SYSTEM_INTERRUPT_ADDR, error);
    this->interruptSystem();
    this->run();
}

void Cpu::initialize(int memory[])
{
    this->memory.initialize(memory);
}

void Cpu::writeInterruptProgram(int interruptAddr, ErrorType error) 
{
    switch (error)
    {
    case MESSAGE_OUT_OF_RANGE:
    {
        int instructions[] = {
            1, 73, // I
            9, 2,
            1, 110, // n
            9, 2,
            1, 118, // v
            9, 2,
            1, 97, // a
            9, 2,
            1, 108, // l
            9, 2,
            1, 105, // i
            9, 2,
            1, 100, // d
            9, 2,
            1, 32, // _
            9, 2,
            1, 105, // i
            9, 2,
            1, 110, // n
            9, 2,
            1, 100, // d
            9, 2,
            1, 101, // e
            9, 2,
            1, 120, // x
            9, 2,
            1, 33, // !
            9, 2,
            1, 10, // \n
            9, 2,
            50 // END program
        };
        bool isSwitch = false;
        if (this->memory.getMode() == USER_MODE) {
            this->memory.setMode(SYSTEM_MODE);
            isSwitch = true;
        }

        int intstructionLength = (sizeof(instructions)) / (sizeof(*instructions));
        //write message to system intTimer memory 
        for (int i = 0; i < intstructionLength; i++)
        {
            memory.write(interruptAddr + i, instructions[i]);
        }

        //switch to user mode before call this function
        if (isSwitch)
        {
            this->memory.setMode(USER_MODE);
        }
        break;
    }
    case MESSAGE_ILLEGAL_ACCESS:
    {
        int instructions[] = {
            1, 65, // A
            9, 2,
            1, 99, // c
            9, 2,
            1, 99, // c
            9, 2,
            1, 101, // e
            9, 2,
            1, 115, // s
            9, 2,
            1, 115, // s
            9, 2,
            1, 32, // _
            9, 2,
            1, 101, // e
            9, 2,
            1, 114, // r
            9, 2,
            1, 114, // r
            9, 2,
            1, 111, // o
            9, 2,
            1, 114, // r
            9, 2,
            1, 33, // !
            9, 2,
            1, 10, // \n
            9, 2,
            50 // End program!
        };
        bool isSwitch = false;
        if (this->memory.getMode() == USER_MODE) {
            this->memory.setMode(SYSTEM_MODE);
            isSwitch = true;
        }

        int intstructionLength = (sizeof(instructions)) / (sizeof(*instructions));
        //write message to system intTimer memory 
        for (int i = 0; i < intstructionLength; i++)
        {
            memory.write(interruptAddr + i, instructions[i]);
        }

        //switch to user mode before call this function
        if (isSwitch)
        {
            this->memory.setMode(USER_MODE);
        }
        break;
    }
    }
}

void Cpu::interruptSystem()
{
    if (!this->isInterrupt()) {
        // set interrupt = true
        setInterrupt(true);

        //set system mode
        this->memory.setMode(SYSTEM_MODE);
        //switch stack
        switchToSystemStack();
        //push tmpSP, tmpPC to system stack
        systemSP = storeRegister(systemSP);

        //set new sp, pc
        setNewPcSPRegister(SYSTEM_INTERRUPT_ADDR, systemSP);

        //check timer program
        if (this->memory.read(SYSTEM_INTERRUPT_ADDR) == 0) {
            iret();
        }
    }
}