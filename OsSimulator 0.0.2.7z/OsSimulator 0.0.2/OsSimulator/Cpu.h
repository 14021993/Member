#pragma once
#include "Memory.h"

class Cpu
{
public:
    int TIMER_INTERRUPT_ADDR = 1000;
    int SYSTEM_INTERRUPT_ADDR = 1500;

private:
    int registerPC;
    int registerSP;
    int registerIR;
    int registerAC;
    int registerX;
    int registerY;
    int userSP;
    int systemSP;
    Memory memory;
    int timer;
	int count;
    bool interrupt;
    bool terminate;

public:
    Cpu();
    ~Cpu();

	/*
	Function: fetchIR()
	Description: Instructions are fetched into the IR from memory
	@param: NA
	@return: NA
	*/
    void fetchIR();

	/*
	Function: executeInstruction()
	Description: Execute Instructions
	@param: NA
	@return: NA
	*/
    void executeInstruction();

	/*
	Function: run()
	Description: run CPU 
	@param: NA
	@return: NA
	*/
    void run();

	/*
	Function: printMessage()
	Description: Print message
	@param: ErrorType error
	@return: NA
	*/
    void printMessage(ErrorType error);

	/*
	Function: setInterrupt()
	Description: Set interrrupt process 
	@param: bool interrupt
	@return: NA
	*/
    void Cpu::setInterrupt(bool interrupt);

	/*
	Function: isInterrupt()
	Description: Check status interrupt of process
	@param: NA
	@return: bool
	*/
    bool Cpu::isInterrupt();

	/*
	Function: setTerminate()
	Description: Set terminate process
	@param: bool terminate
	@return: NA
	*/
    void Cpu::setTerminate(bool terminate);

	/*
	Function: isTerminate()
	Description: Check status terminate of process
	@param: NA
	@return: bool
	*/
    bool Cpu::isTerminate();

	/*
	Function: interruptTimer()
	Description: Interrupt process by timer 
	@param: NA
	@return: NA
	*/
    void interruptTimer();

	/*
	Function: setTimer()
	Description: Set timer
	@param: int value
	@return: NA
	*/
    void setTimer(int value);

	/*
	Function: interruptSystem()
	Description: Interrupt system 
	@param: NA
	@return: NA
	*/
    void interruptSystem();

	/*
	Function: writeInterruptProgram()
	Description: Write Interrupt program
	@param: int interruptAddr
	@param: ErrorType error
	@return: NA
	*/
    void writeInterruptProgram(int interruptAddr, ErrorType error);

	/*
	Function: initialize()
	Description: initialize CPU class 
	@param: int memory[]
	@return: NA
	*/
    void initialize(int memory[]);

private:

	/*
	Function: switchToUserStack()
	Description: Go to stack of User
	@param: NA
	@return: NA
	*/
    void switchToUserStack();

	/*
	Function: switchToSystemStack()
	Description: Go to stack of System
	@param: NA
	@return: NA
	*/
    void switchToSystemStack();

	/*
	Function: storeRegister()
	Description: Store for Register
	@param: NA
	@return: NA
	*/
    int  storeRegister(int stackPoint);

	/*
	Function: setNewPcSPRegister()
	Description: Set new PC, SP register
	@param: int pc
	@param: int sp
	@return: NA
	*/
    void setNewPcSPRegister(int pc, int sp);

	/*
	Function: iret()
	Description: Restore registers, set user mode
	@param: NA
	@return: NA
	*/
    void iret();

	/*
	Function: restoreRegisterFromStack()
	Description: Restore registers from stack
	@param: int stackPoint
	@return: int
	*/
    int  restoreRegisterFromStack(int stackPoint);

	/*
	Function: loadValue()
	Description: Load the value into the AC
	@param: NA
	@return: NA
	*/
    void loadValue();

	/*
	Function: loadAddr()
	Description: Load the value at the address into the AC
	@param: int addr
	@return: NA
	*/
    void loadAddr();

	/*
	Function: loadInd()
	Description: Load the value from the address found in the given address into the AC
	@param: int addr
	@return: NA
	*/
    void loadInd();

	/*
	Function: loadIndX()
	Description: Load the value at (address+X) into the AC
	@param: int addr
	@return: NA
	*/
    void loadIndX();

	/*
	Function: loadIndY()
	Description: Load the value at (address+Y) into the AC
	@param: int addr
	@return: NA
	*/
    void loadIndY();

	/*
	Function: loadSpX()
	Description: Load from (Sp+X) into the AC
	@param: NA
	@return: NA
	*/
    void loadSpX();

	/*
	Function: storeAddr()
	Description: Store the value in the AC into the address
	@param: int addr
	@return: NA
	*/
    void storeAddr();

	/*
	Function: get()
	Description: Gets a random int from 1 to 100 into the AC
	@param: NA
	@return: NA
	*/
    void get();

	/*
	Function: putPort()
	Description: If port=1, writes AC as an int to the screen
				 If port=2, writes AC as a char to the screen
	@param: NA
	@return: NA
	*/
    void putPort();

	/*
	Function: addX()
	Description: Add the value in X to the AC
	@param: NA
	@return: NA
	*/
    void addX();

	/*
	Function: addY()
	Description: Add the value in Y to the AC
	@param: NA
	@return: NA
	*/
    void addY();

	/*
	Function: subX()
	Description: Subtract the value in X from the AC
	@param: NA
	@return: NA
	*/
    void subX();

	/*
	Function: subY()
	Description: Subtract the value in Y from the AC
	@param: NA
	@return: NA
	*/
    void subY();

	/*
	Function: copyToX()
	Description: Copy the value in the AC to X
	@param: NA
	@return: NA
	*/
    void copyToX();

	/*
	Function: copyFromX()
	Description: Copy the value in X to the AC
	@param: NA
	@return: NA
	*/
    void copyFromX();

	/*
	Function: copyToY()
	Description: Copy the value in the AC to Y
	@param: NA
	@return: NA
	*/
    void copyToY();

	/*
	Function: copyFromY()
	Description: Copy the value in Y to the AC
	@param: NA
	@return: NA
	*/
    void copyFromY();

	/*
	Function: copyToSP()
	Description: Copy the value in the AC to SP
	@param: NA
	@return: NA
	*/
    void copyToSP();

	/*
	Function: copyFromSP()
	Description: Copy the value in SP to the AC
	@param: NA
	@return: NA
	*/
    void copyFromSP();

	/*
	Function: jumpAddr()
	Description: Jump to the address
	@param: int addr
	@return: NA
	*/
    void jumpAddr();

	/*
	Function: jumpIfEqualAddr()
	Description: Jump to the address only if the value in the AC is zero
	@param: int addr
	@return: NA
	*/
    void jumpIfEqualAddr();

	/*
	Function: jumpIfNotEqualAddr()
	Description: Jump to the address only if the value in the AC is not zero
	@param: int addr
	@return: NA
	*/
    void jumpIfNotEqualAddr();

	/*
	Function: callAddr()
	Description: Push return address onto stack, jump to the address
	@param: int addr
	@return: NA
	*/
    void callAddr();

	/*
	Function: ret()
	Description: Pop return address from the stack, jump to the address
	@param: NA
	@return: NA
	*/
    void ret();

	/*
	Function: incX()
	Description: Increment the value in X
	@param: NA
	@return: NA
	*/
    void incX();

	/*
	Function: decX()
	Description: Decrement the value in X
	@param: NA
	@return: NA
	*/
    void decX();

	/*
	Function: pushAC()
	Description: Push AC onto stack
	@param: NA
	@return: NA
	*/
    void pushAC();

	/*
	Function: popAC()
	Description: Pop from stack into AC
	@param: NA
	@return: NA
	*/
    void popAC();

	/*
	Function: inc()
	Description: Set system mode, switch stack, push SP and PC, set new SP and PC
	@param: NA
	@return: NA
	*/
    void inc();

	/*
	Function: end()
	Description: End execution
	@param: NA
	@return: NA
	*/
    void end();

	/*
	Function: printNumber()
	Description: Print number
	@param: int data
	@return: NA
	*/
    void printNumber(int data);

	/*
	Function: printCharacter()
	Description: Print characters
	@param: int data
	@return: NA
	*/
    void printCharacter(int data);
};

