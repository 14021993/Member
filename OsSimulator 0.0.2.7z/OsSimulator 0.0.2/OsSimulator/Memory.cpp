#include "Memory.h"

Memory::Memory()
{
    this->mode = USER_MODE;
    int i = 0;
    for (i = 0; i < MEMORY_SIZE; i++)
    {
        this->mem[i] = 0;
    }
}

Memory::~Memory()
{

}

void Memory::initialize(int mem[])
{
    int i = 0;
    for (i = 0; i < MEMORY_SIZE; i++)
    {
        this->mem[i] = mem[i];
    }
}

int Memory::read(int address)
{
    bool isNotInRangeAddress = (address < 0) && (address >= MEMORY_SIZE);
    bool isIllegalAccess = (this->mode == USER_MODE) && (address > LAST_ADDRESS_OF_USER_MEMORY);
    if (isNotInRangeAddress)
    {
        throw OutOfRangeException();
    }

    if (isIllegalAccess)
    {
        throw IllegalAccessException();
    }
    return this->mem[address];
}

void Memory::write(int address, int data)
{
    bool isNotInRangeAddress = (address < 0) || (address >= MEMORY_SIZE);
    bool isIllegalAccess = (this->mode == USER_MODE) && (address > LAST_ADDRESS_OF_USER_MEMORY);
    if (isNotInRangeAddress)
    {
        throw OutOfRangeException();
    }

    if (isIllegalAccess)
    {
        throw IllegalAccessException();
    }
    this->mem[address] = data;
}

ModeType Memory::getMode()
{
    return this->mode;
}

void Memory::setMode(ModeType mode)
{
    this->mode = mode;
}
int Memory::getCurrentAddr()
{
	return sizeof(this->mem);
}