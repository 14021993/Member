#pragma once

#include "OsSimulatorTypes.h"
#include "IllegalAccessException.h"
#include "OutOfRangeException.h"
using namespace std;
#include <iostream>

class Memory
{
private:
    int mem[MEMORY_SIZE];
    ModeType mode;
public:
    Memory();
    ~Memory();

	/*
	Function: read()
	Description: returns the value at the address
	@param: int address
	@return: int
	*/
    int read(int address);


	/*
	Function: write()
	Description: writes the data to the address
	@param: int address
	@param: int data
	@return: NA
	*/
    void write(int address, int data);

	/*
	Function: getMode()
	Description: Get mode
	@param: NA
	@return: ModeType
	*/
    ModeType getMode();

	/*
	Function: setMode()
	Description: Set mode
	@param: ModeType mode
	@return: NA
	*/
    void setMode(ModeType mode);

	/*
	Function: initialize()
	Description: initialize
	@param: int mem[]
	@return: NA
	*/
    void initialize(int mem[]);

	/*
	Function: getCurrentAddr()
	Description: get current address
	@param: NA
	@return: int
	*/
	int getCurrentAddr();
};

