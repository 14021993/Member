#include "OsSimulator.h"


OsSimulator::OsSimulator()
{

}


OsSimulator::~OsSimulator()
{

}

void OsSimulator::loadProgram(string fileName, int memory[])
{
    ifstream file;
    file.open(fileName);
    int address = 0;
    string programAttribute;
    string jumpAddress;
    
    while (!file.eof())
    {
        string line;
        getline(file, line);
        programAttribute = this->getProgramAtrritube(line);
        
        if (programAttribute != "")
        {
            memory[address++] = atoi(programAttribute.c_str());
        }
        else
        {
            jumpAddress = this->getJumpAddress(line);
            if (jumpAddress != "")
            {
                address = atoi(jumpAddress.c_str());
            }
            else
            {
                /* Do nothing */
            }
        }
    }
}

string OsSimulator::getProgramAtrritube(string line)
{
    string programAttribute = "";
    std::smatch m;
    std::regex e("\^\-?\[0-9]+");

    std::regex_search(line, m, e);
    programAttribute = m[0];
    return programAttribute;
}

string OsSimulator::getJumpAddress(string line)
{
    string jumpAddress = "";
    std::smatch m;
    std::regex e ("\^\\.[0-9]+");
    std::regex f("[0-9]");
    std::regex_search(line, m, e);
    if (!m.empty())
    {
        std::regex_search(line, m, e);
        string tmp = m[0];
        jumpAddress = tmp.substr(1);
    }
    return jumpAddress;
}

void OsSimulator::start(int memory[], int timer) 
{
    this->cpu.setTimer(timer);
    this->cpu.initialize(memory);
    this->cpu.run();
}

