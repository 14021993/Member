#pragma once
#include "Cpu.h"
#include <iostream>
#include <fstream>
#include <string>
#include <regex>

class OsSimulator
{
private:
    Cpu cpu;
public:
    OsSimulator();
    ~OsSimulator();

	/*
	Function: loadProgram()
	Description: load program 
	@param: string fileName
	@param: int memory[]
	@return: NA
	*/
    void loadProgram(string fileName, int memory[]);

	/*
	Function: start()
	Description: start program 
	@param: int timer
	@param: int memory[]
	@return: NA
	*/
    void start(int memory[], int timer);
private:

	/*
	Function: getProgramAtrritube()
	Description: Get attribute from file path 
	@param: string line
	@return: string (attributes)
	*/
    string getProgramAtrritube(string line);

	/*
	Function: getJumpAddress()
	Description: Get address from file path
	@param: string line
	@return: string (address)
	*/
    string getJumpAddress(string line);
};

