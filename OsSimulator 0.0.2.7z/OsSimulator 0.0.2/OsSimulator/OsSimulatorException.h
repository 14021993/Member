#pragma once
#include <exception>

using namespace std;

class OsSimulatorException : public exception
{
public:
    const char * what() const throw()
    {
        return "Division By Zero Exception";
    }
};

