
#define START_USER_STACK_INDEX 999
#define START_SYSTEM_STACK_INDEX 1999
#define MEMORY_SIZE 2000
#define LAST_ADDRESS_OF_USER_MEMORY 999

enum ModeType
{
    USER_MODE = 0,
    SYSTEM_MODE = 1,
    INVALID_MODE = 2
};

enum ErrorType
{
    MESSAGE_OUT_OF_RANGE = 0,
    MESSAGE_ILLEGAL_ACCESS = 1
};

enum InstructionType
{
	LOAD_VALUE				= 1,
	LOAD_ADDR				= 2,
	LOAD_IND				= 3,
	LOAD_IND_X				= 4,
	LOAD_IND_Y				= 5,
	LOAD_SP_X				= 6,
	STORE_ADDR				= 7,
	GET						= 8,
	PUT_PORT				= 9,
	ADD_X					= 10,
	ADD_Y					= 11,
	SUB_X					= 12,
	SUB_Y					= 13,
	COPY_TO_X				= 14,
	COPY_FROM_X				= 15,
	COPY_TO_Y				= 16,
	COPY_FROM_Y				= 17,
	COPY_TO_SP				= 18,
	COPY_FROM_SP			= 19,
	JUMP_ADDR				= 20,
	JUMP_IF_EQUAL_ADDR		= 21,
	JUMP_IF_NOT_EQUAL_ADDR	= 22,
	CALL_ADDR				= 23,
	RET						= 24,
	INC_X					= 25,
	DEC_X					= 26,
	PUSH_AC					= 27,
	POP_AC					= 28,
	INT						= 29,
	IRET					= 30,
	END						= 50,


};
