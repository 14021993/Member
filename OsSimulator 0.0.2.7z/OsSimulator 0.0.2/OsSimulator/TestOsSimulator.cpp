#include "OsSimulator.h"

int main(int argc, char* argv[])
{
	try
	{
		OsSimulator simulator;
		int memory[MEMORY_SIZE];
		for (int i = 0; i < MEMORY_SIZE; i++)
		{
			memory[i] = 0;
		}
		string programFile = argv[2];
		simulator.loadProgram(programFile, memory);
        string timerStr = argv[3];
        int timer = atoi(timerStr.c_str());
		simulator.start(memory, timer);
		system("pause");
	}
	catch (exception)
	{
		cout << "Exception";
	}
}
